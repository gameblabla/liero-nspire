================
LIERO for TI Nspire
================

Ported to TI Nspire CX by gameblabla

Liero ported to the TI Nspire.
Liero is kind of like Work but except it's not turn-by-turn.
I have no idea if this work properly on B&W Nspires though, let me know  !

Before you play the game,
configure the controls in Options ->  Player 1 Options.
Then press CTRL on commands like "Fire" to change the default mapping.

=============
INSTALLATION
=============

Ndless is required for this game.
Make sure you have enough memory for this game !
If you're not sure, clean your calc up with Ncleaner and reset it.

This particular game does not support relative directories
so you need to put all the folder "data" in a new folder called "liero".
The "liero" folder must be created at the root of your calc.
Then put the data folder in that folder along with the tns file.
To start the game, start "liero.tns".

